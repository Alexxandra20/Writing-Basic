const words = [
    {
        word: "brother",
        hint: "How do you write HERMANO in English?"
    },
    {
        word: "father",
        hint: "How do you write PAPÁ in English"
    },
    {
        word: "mother",
        hint: "How do you write MAMÁ in English"
    },
    {
        word: "son",
        hint: "How do you write HIJO in English"
    },
    {
        word: "sister",
        hint: "How do you write HERMANA in English"
    },
    {
        word: "grandfather",
        hint: "How do you write ABUELO in English"
    },
    {
        word: "grandmother",
        hint: "How do you write ABUELA in English"
    },
    {
        word: "uncle",
        hint: "How do you write TÍO in English"
    },
    {
        word: "aunt",
        hint: "How do you write TÍA in English"
    },
    {
        word: "wife",
        hint: "How do you write ESPOSA in English"
    },
    {
        word: "husband",
        hint: "How do you write ESPOSO in English"
    },
    {
        word: "cousin",
        hint: "How do you write PRIMO in English"
    },
]