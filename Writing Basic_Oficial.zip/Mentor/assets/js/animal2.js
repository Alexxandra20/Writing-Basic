const words = [
    {
        word: "elephant",
        hint: "How do you write ELEFANTE in English?"
    },
    {
        word: "snake",
        hint: "How do you write SERPIENTE in English?"
    },
    {
        word: "dolphin",
        hint: "How do you write DELFIN in English?"
    },
    {
        word: "butterfly",
        hint: "How do you write MARIPOSA in English?"
    },
    {
        word: "hen",
        hint: "How do you write GALLINA in English?"
    },
    {
        word: "giraffe",
        hint: "How do you write JIRAFA in English?"
    },
    {
        word: "donkey",
        hint: "How do you write BURRO in English?"
    },
    {
        word: "frog",
        hint: "How do you write RANA in English?"
    },
    {
        word: "whale",
        hint: "How do you write BALLENA in English?"
    },
    {
        word: "owl",
        hint: "How do you write BUHO in English?"
    },
    {
        word: "sheep",
        hint: "How do you write OVEJA in English?"
    },
]