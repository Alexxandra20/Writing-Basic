const words = [
  {
      word: "red",
      hint: "How do you write ROJO in English?"
  },
  {
      word: "yellow",
      hint: "How do you write AMARILLO in English"
  },
  {
      word: "green",
      hint: "How do you write VERDE in English"
  },
  {
      word: "grey",
      hint: "How do you write GRIS in English"
  },
  {
      word: "blue",
      hint: "How do you write AZUL in English"
  },
  {
      word: "brown",
      hint: "How do you write CAFÉ in English"
  },
  {
      word: "golden",
      hint: "How do you write DORADO in English"
  },
  {
      word: "violet",
      hint: "How do you write VIOLETA in English"
  },
  {
      word: "light blue",
      hint: "How do you write CELESTE in English"
  },
  {
      word: "lilac",
      hint: "How do you write LILA in English"
  },
  {
      word: "silver",
      hint: "How do you write PLATEADO in English"
  },
  {
      word: "dark purple ",
      hint: "How do you write MORADO OSCURO in English"
  },
]
