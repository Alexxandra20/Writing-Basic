const words = [
    {
        word: "notebook",
        hint: "How do you write CUADERNO in English?"
    },
    {
        word: "scissor",
        hint: "How do you write TIJERA in English"
    },
    {
        word: "paper",
        hint: "How do you write PAPEL in English"
    },
    {
        word: "colors",
        hint: "How do you write COLORES in English"
    },
    {
        word: "book",
        hint: "How do you write LIBRO in English"
    },
    {
        word: "backpack",
        hint: "How do you write MOCHILA in English"
    },
    {
        word: "sharpener",
        hint: "How do you write SACAPUNTA in English"
    },
    {
        word: "pencil",
        hint: "How do you write LAPICERO in English"
    },
    {
        word: "pencil case",
        hint: "How do you write ESTUCHE in English"
    },
    {
        word: "rule",
        hint: "How do you write REGLA in English"
    },
    {
        word: "markers",
        hint: "How do you write PLUMONES in English"
    },
    {
        word: "file",
        hint: "How do you write MORADO FOLDER in English"
    },
  ]
  