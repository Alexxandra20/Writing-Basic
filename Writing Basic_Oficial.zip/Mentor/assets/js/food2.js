const words = [
    {
        word: "bread",
        hint: "How do you write PAN in English?"
    },
    {
        word: "potatoes",
        hint: "How do you write PAPAS in English"
    },
    {
        word: "tomato",
        hint: "How do you write TOMATE in English"
    },
    {
        word: "apple",
        hint: "How do you write MANZANA in English"
    },
    {
        word: "grape",
        hint: "How do you write UVA in English"
    },
    {
        word: "wine",
        hint: "How do you write VINO in English"
    },
    {
        word: "cake",
        hint: "How do you write PASTEL in English"
    },
    {
        word: "meat",
        hint: "How do you write CARNE in English"
    },
    {
        word: "cookie",
        hint: "How do you write GALLETA in English"
    },
    {
        word: "orange",
        hint: "How do you write NARANJA in English"
    },
    {
        word: "fish",
        hint: "How do you write PESCADO in English"
    },
    {
        word: "chips",
        hint: "How do you write PAPAS FRITAS in English"
    },
]