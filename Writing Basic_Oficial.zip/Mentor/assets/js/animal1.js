function prueba1() {
	let x = document.forms["myForm"]["fname"].value;
	if (x == "Dog") {
	  alert("It is correct!");
	  return false;
	}else{
	  alert("Try it again")
	}
  }
  
  function prueba2() {
	  let x = document.forms["myForm2"]["fname2"].value;
	  if (x == "Cat") {
		  alert("It is correct!")
		  return false;
	  }else{
	  alert("Try it again")
	  }
  }
  
  function prueba3() {
	let x = document.forms["myForm3"]["fname3"].value;
	if (x == "Bird") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba4() {
	let x = document.forms["myForm4"]["fname4"].value;
	if (x == "Cow") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba5() {
	let x = document.forms["myForm5"]["fname5"].value;
	if (x == "Wolf") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba6() {
	let x = document.forms["myForm6"]["fname6"].value;
	if (x == "Giraffe") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba7() {
	let x = document.forms["myForm7"]["fname7"].value;
	if (x == "Pig", "Pork") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba8() {
	let x = document.forms["myForm8"]["fname8"].value;
	if (x == "Rabbit", "bunny") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba9() {
	let x = document.forms["myForm9"]["fname9"].value;
	if (x == "Chick") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  
  function prueba10() {
	let x = document.forms["myForm10"]["fname10"].value;
	if (x == "Penguin") {
	  alert("It is correct!");
	  return false;
	}else{
	alert("Try it again");
	}
  }
  